package org.wordpress.android.ui.prefs;

public interface PreferenceHint {
    boolean hasHint();
    String getHint();
    void setHint(String hint);
}
