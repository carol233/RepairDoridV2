package org.wordpress.android.ui.stats.models;

import java.io.Serializable;

public class BaseStatsModel implements Serializable{

}
