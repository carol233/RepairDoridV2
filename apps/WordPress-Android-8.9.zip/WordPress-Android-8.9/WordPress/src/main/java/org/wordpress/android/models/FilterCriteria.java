package org.wordpress.android.models;

public interface FilterCriteria {
    String getLabel();
}
