
package org.wordpress.android;

public class Constants {
    public static final String URL_TOS = "https://en.wordpress.com/tos";
    public static final String URL_AUTOMATTIC = "https://automattic.com";
    public static final String URL_PRIVACY_POLICY = "https://automattic.com/privacy";
}
